<?php
include("../includes/header.php");
include("../includes/functions.php");
?>


<!-- Lecturer Nav -->
<?php include("../includes/lecturernav.php"); ?>


<!-- Posts -->
<section id="posts">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header">
                  <h4>Students</h4>
               </div>
               <table class="table table-striped">
                  <thead class="thead-dark">
                     <tr>
                        <th>#</th>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>Email</th>
                        <th>Action</th>
                        <th>Status</th>
                     </tr>
                  </thead>
                  <tbody>

                     <?php
                     $query = "SELECT * FROM students ORDER BY std_id DESC";
                     $select_all_students = mysqli_query($connection, $query);

                     while ($row = mysqli_fetch_assoc($select_all_students)) {

                        $std_id = $row['std_id'];
                        $firstname = $row['firstname'];
                        $lastname = $row['lastname'];
                        $email = $row['email'];
                        $status = $row['status'];

                     ?>
                        <tr>
                           <td><?php echo $std_id; ?></td>
                           <td><?php echo $firstname; ?></td>
                           <td><?php echo $lastname; ?></td>
                           <td><?php echo $email; ?></td>
                           <form method="post" action=" " onSubmit="window.location.reload()">
                              <td>
                                 <a href="index.php?action=approve&req_id=<?= $std_id ?>" class="btn btn-success">Approve</a>
                                 <a href="index.php?action=decline&req_id=<?= $std_id ?>" class="btn btn-danger"> Decline </a>
                              </td>

                           </form>
                           <td><?php

                                 if ($status === "APPROVED") {
                                    echo "<p style='color:green'> <strong> $status </strong></p>";
                                 } elseif ($status === "DECLINED") {
                                    echo "<p style='color:red'> <strong> $status </strong></p>";
                                 } else {
                                    echo "<p style='color:#E0A800'> <strong> $status </strong></p>";
                                 }

                                 ?>
                           </td>
                        </tr>


                     <?php }; ?>

                     <!-- Status Update Query -->
                     <?php
                     // APPROVE
                     if (isset($_GET['action']) && $_GET['action'] == "approve") {

                        $request_id = $_GET['req_id'];
                        $approve = "APPROVED";

                        $query = "UPDATE students SET ";
                        $query .= "status  = '{$approve}' ";
                        $query .= "WHERE std_id = {$request_id} ";

                        header("Location: index.php");

                        $update_query = mysqli_query($connection, $query);
                        if (!$update_query) {
                           die("Query failed" . mysqli_error($connection));
                        }
                     };

                     if (isset($_GET['action']) && $_GET['action'] == "decline") {

                        // Declined
                        $request_id = $_GET['req_id'];
                        $declined = "DECLINED";

                        $query = "UPDATE students SET ";
                        $query .= "status  = '{$declined}' ";
                        $query .= "WHERE std_id = {$request_id} ";

                        header("Location: index.php");

                        $update_query = mysqli_query($connection, $query);
                        if (!$update_query) {
                           die("Query failed" . mysqli_error($connection));
                        }
                     };

                     ?>




                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</section>



<?php include("../includes/footer.php"); ?>