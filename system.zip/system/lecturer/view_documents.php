 <?php
   include("../includes/header.php");
   include("../includes/functions.php");
   ?>


 <!-- Lecturer Nav -->
 <?php include("../includes/lecturernav.php"); ?>

 <section id="posts">
    <div class="container">
       <div class="row">
          <div class="col-md-12">
             <div class="card">
                <div class="card-header">
                   <h4>Students</h4>
                </div>
                <table class="table table-striped table-bordered">
                   <thead class="thead-dark">
                      <tr>
                         <th>#</th>
                         <th>Doc#</th>
                         <th>Firstname</th>
                         <th>Lastname</th>
                         <th>Document text</th>
                         

                      </tr>
                   </thead>
                   <tbody>

                      <?php

                        $query = "SELECT * FROM students JOIN documents ON students.std_id = documents.std_id 
                        JOIN results ON documents.doc_id = results.doc_id";
                        $select_all_students = mysqli_query($connection, $query);

                        while ($row = mysqli_fetch_assoc($select_all_students)) {

                           $std_id = $row['std_id'];
                           $firstname = $row['firstname'];
                           $lastname = $row['lastname'];
                           $upload_document = $row['upload_document'];
                           $doc_id = $row['doc_id'];

                        ?>
                         <tr>
                            <td><?php echo $std_id; ?></td>
                            <td><?php echo $doc_id; ?></td>
                            <td><?php echo $firstname; ?></td>
                            <td><?php echo $lastname; ?></td>
                            <td><?php echo $upload_document; ?></td>
                         </tr>


                      <?php }; ?>






                   </tbody>
                </table>
             </div>
          </div>
       </div>
    </div>
 </section>










 <?php include("../includes/footer.php"); ?>