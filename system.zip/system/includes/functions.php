<?php


function fill_form()
{
   global $connection;
   $firstname = $_POST['firstname'];
   $lastname = $_POST['lastname'];
   $email = $_POST['email'];
   $password = $_POST['password'];
   $real_pass = $_POST['password'];
   $re_password = $_POST['re_password'];

   $status = "pending";

   $query = mysqli_query($connection, "SELECT email FROM students WHERE email='$email'");
   $numrows = mysqli_num_rows($query);

   if (!$numrows >= 1) {
      $row = mysqli_fetch_array($query);
      if ($password != $re_password) {

         echo "<p class='alert alert-danger'>Password didnt match</p>";
      } else {
         $query = "INSERT INTO students(firstname, lastname, email, password, status) ";
         $query .= "VALUES('{$firstname}','{$lastname}','{$email}','{$real_pass}','{$status}') ";
         $signup_query = mysqli_query($connection, $query);


         if (!$signup_query) {
            die("Query failed" . mysqli_error($connection));
         }

         echo "<p class='alert alert-success'>Your Account was successfully registered. Wait for the Lecturer approval and login.</p>";
      }
   } else {
      echo "<p class='alert alert-danger'>Email already taken</p>";
   }
}


// Login Student
function loginStudent()
{
   global $connection;
   $std_email =  $_POST['std_email'];
   $std_password =  $_POST['std_password'];

   $query = mysqli_query($connection, "SELECT std_id FROM students WHERE email='$std_email' and password='$std_password' and status = 'APPROVED'");

   $granted_students = mysqli_query($connection, $query);
   $row = mysqli_fetch_assoc($granted_students);
   $status = $row['status'];

   $numrows = mysqli_num_rows($query);

   if ($numrows >= 1) {
      $row = mysqli_fetch_array($query);
      $_SESSION['std_id'] = $row['std_id'];

      header('location:student/index.php');
   } elseif ($status != 'APPROVED') {
      echo "<p class='alert alert-warning'>Not yet approved</p>";
   } else {
      echo "<p class='alert alert-danger'>Invalid credentials</p>";
   }
}


// Login Lecturer
function loginLecturer()
{
   global $connection;
   $lec_email = $_POST['lec_email'];
   $lec_pass = $_POST['lec_pass'];

   if ($lec_email === "lecturer@gmail.com" && $lec_pass === "12345") {
?>
      <script>
         window.open("lecturer/index.php");
      </script>
   <?php
   } else {
      echo "<p class='alert alert-danger'>Lecturer: Invalid credentials</p>";
   }
}



function document_uploading()
{
   global $connection;


   // Get text inputs
   $purpose_of_upload =  $_POST['purpose_of_upload'];
   $group_single = $_POST['group_single'];
   $question = $_POST['question'];
   $date = date("l jS \of F Y h:i:s A");

   // moving document
   $upload_document = $_FILES['upload_document']['name'];
   $file_temp = $_FILES['upload_document']['tmp_name'];

   $check = substr("$upload_document", -4);

   if ($check !== ".txt") {
   ?>
      <script>
         alert('wrong file');
      </script>
<?php
   } else {
      move_uploaded_file($file_temp, "$upload_document");
      $display_text = file_get_contents($upload_document);

      echo $display_text;



      // Escape the text data
      $escaped = pg_escape_string($display_text);


      session_start();
      $_SESSION['display_text'] = $display_text;


      $query = "INSERT INTO documents(std_id, purpose_of_upload, group_single, question, upload_document,  date_uploaded) ";
      $query .= "VALUES('{$_SESSION['std_id']}', '{$purpose_of_upload}','{$group_single}','{$question}','{$escaped}','{$date}') ";

      $upload_query = mysqli_query($connection, $query);

      if (!$upload_query) {
         die("Query failed" . mysqli_error($connection));
      }

      $query = "SELECT * FROM documents ORDER by doc_id DESC LIMIT 1";
      $select_all_students = mysqli_query($connection, $query);

      $row = mysqli_fetch_assoc($select_all_students);

      $std_id = $row['std_id'];
      $_SESSION['doc_id'] = $row['doc_id'];
      echo  $_SESSION['doc_id'];
   }
}
