<?php
include("../includes/db.php");
error_reporting(0);

?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>MSU | Plagiarism System</title>


   <!-- Link Boostrap css -->
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">



</head>

<body>

   <!-- HEADER -->
   <header id="main-header" class="py-2 bg-primary text-white">
      <div class="container">
         <div class="row">
            <div class="col-md-6 m-auto text-center">
               <img src="../images/main-logo.png" alt="">
               <h5>Midlands State University Plagiarism Detection System</h5>
            </div>
         </div>
      </div>
   </header>