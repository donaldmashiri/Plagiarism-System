function get_6words($sentence)
{
$count = 6;
preg_match("/(?:\w+(?:\W+|$)){0,$count}/", $sentence, $matches);
return $matches[0];
}

function remove_6words($sentence)
{
$count = -6;
preg_match("/(?:\w+(?:\W+|$)){0,$count}/", $sentence, $matches);
return $matches[0];
}



// echo $display_text;
$the_text = $_SESSION['display_text'];
// echo $the_text . "<br>";

if (isset($_POST['check'])) {


// $the_text_array[];
$the_text_next_position = 0;
$the_text_word_count = str_word_count($the_text);

$query = "SELECT upload_document FROM documents ";
$search_query = mysqli_query($connection, $query);
while ($row = mysqli_fetch_assoc($search_query)) {
$document_text = $row['upload_document'];

// $string = '$document_text';
// $subString = strstr($string, '$the_text');
// echo $subString;

$document_word_count = str_word_count($document_text);
echo $document_text . '<br>' . $document_word_count . '<br>';
$next_position = 0;
for ($next_position; $next_position <= $document_word_count; $next_position +=6) { echo 'retrieved text<br>' ; (explode(',', $str, 0)); echo $retrived_text=get_6words($document_text); echo '<br>' ; //add function to delete first 6 words of a string // function remove_word($sentence) // { // $words=array_shift(explode(' ', $sentence));
                           //    return implode(' ', $words);
                           // }

                           // $next_position -= 6;

                           // $string = "$document_text";
                           // $words = explode(' ', $string);

                           // $to_keep = array_slice($words, 4);
                           // $final_string = implode(' ', $to_keep);

                           // echo $final_string;



                           // echo $retrived_text = remove_6words($document_text);
                           // echo ' <br>';
   }
   }






   for ($next_position; $next_position <= $the_text_word_count; $next_position +=6) { $text_segment=substr($the_text, 6); // if ($text_segment !=$document_text) { // echo "<mark>$text_segment</mark>" ; // } // echo $text_segment; // $the_text_array . push($text_segment); } $score=0; foreach ($the_text_array as $t) { if ($the_text_array . include($t)) { $score++; } } // $plag=similar_text('$the_text', '$document_text' , $perc); // echo "similarity: $plag ($perc %)\n" ; } // $query="SELECT upload_document FROM documents; " ; // $search_query=mysqli_query($connection, $query); // while ($row=mysqli_fetch_assoc($search_query)) { // $s_upload_document=$row['upload_document']; // // echo $display_text; // } // $sim=similar_text('$display_text', '$s_upload_document' , $perc); // echo "similarity: $sim ($perc %)\n" ;