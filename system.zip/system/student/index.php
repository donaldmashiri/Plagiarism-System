 <?php
   include("../includes/header.php");
   include("../student/navbar.php");
   include("../includes/functions.php");
   ?>


 <!-- CONTACT SECTION -->
 <section id="contact" class="py-3">
    <div class="container">
       <div class="row">
          <div class="col-md-4">
             <div class="card p-4">
                <div class="card-body">
                   <h4>How this system work.</h4>
                   <p>1. Select the type of document you want to upload</p>
                   <p>2. Enter question the assignment. If you are uploading the documentation just type
                      <i>documentation</i> </p>
                   <p>3. Click browse and go Select the your document you want to upload </p>
                   <p>4. The text in the document will be shown in the field set</p>
                   <p>5. Plagirized text will be highligted in <b style="color: red;">red</b> </p>

                </div>
             </div>
          </div>
          <div class="col-md-8">
             <div class="card p-4">
                <div class="card-body">
                   <h3 class="text-center">Read the manual on your left and procced</h3>
                   <hr>
                   <form action="" method="post" enctype="multipart/form-data">
                      <div class="row">

                         <div class="col-md-10">
                            <div class="input-group mb-3">
                               <div class="input-group-prepend">
                                  <label class="input-group-text" for="inputGroupSelect01">Type of Upload</label>
                               </div>
                               <select name="purpose_of_upload" class="custom-select" id="inputGroupSelect01">
                                  <option selected></option>
                                  <option value="Assignment">Assignment</option>
                                  <option value="Documentation">Documentation</option>
                                  <option value="other">other</option>
                               </select>
                            </div>
                         </div>

                         <div class="col-md-10">
                            <div class="input-group mb-3">
                               <div class="input-group-prepend">
                                  <label class="input-group-text" for="inputGroupSelect01">Group/Single</label>
                               </div>
                               <select name="group_single" class="custom-select" id="inputGroupSelect01">
                                  <option selected></option>
                                  <option value="Group">Group</option>
                                  <option value="Single">Single</option>
                                  <option value="other">other</option>
                               </select>
                            </div>
                         </div>
                         <div class="col-md-12">
                            <div class="form-group">
                               <textarea class="form-control" name="question" placeholder="Question:"></textarea>
                            </div>
                         </div>
                         <div class="col-md-8">
                            <div class="form-group" style="background-color: #E9ECEF;">
                               <label for="myfile">Choose file to upload</label>
                               <input type="file" name="upload_document" class="form-control">
                            </div>
                         </div>

                      </div>
                      <div class="row">
                         <div class="col-md-12 mt-3">
                            <div class="form-group">
                               <input type="submit" value="Submit" name="upload_document" class="btn btn-outline-secondary btn-block">
                            </div>
                         </div>
                      </div>
                   </form>

                </div>
             </div>
          </div>
       </div>
    </div>
 </section>


 <section class="py-3 mb-3 bg-light">
    <div class="info-header">
       <h5 class="text-info text-center">
          Your Uploaded Document
       </h5>
    </div>
 </section>


 <section id="contact" class="py-3 m-5">
    <div class="container">
       <div class="row">
          <div class="col-md-12">
             <div style="border-color: green; border-style: dotted;" class="card p-4">
                <?php

                  if (isset($_POST['upload_document'])) {
                     document_uploading();
                  }

                  ?>
             </div>
             <form action="" method="post">
                <div class="text-center mt-3">
                   <button type="submit" class="btn btn-success" name="check_plagiarism">Check plagiarism</button>
                </div>
             </form>
          </div>
       </div>
    </div>
 </section>


 <section class="py-3 mb-3 bg-light">
    <div class="info-header">
       <h5 class="text-info text-center">
          Your Results
       </h5>
    </div>
 </section>




 <?php

   if (isset($_POST['check_plagiarism'])) {

      $the_text = $_SESSION['display_text'];


      try {
         $url = 'https://www.prepostseo.com/apis/checkPlag';
         $data = array(
            "key" => '05e93d08984ca0cc3a258ca9f0d41afe',
            "data" =>
            $_SESSION['display_text']

         );
         $curl = curl_init($url);
         curl_setopt($curl, CURLOPT_POST, true);
         curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
         curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
         $word_data = curl_exec($curl);
         curl_close($curl);
         $word_data = (array) json_decode($word_data);
         // var_dump($word_data);

         // echo $word_data['totalQueries'];
         // echo '.</br>';
         // echo $word_data['plagPercent'];
         // echo '.</br>';
         // echo $word_data['uniquePercent'];
         // echo '.</br>';
         $order_details = (array) $word_data['details'];

   ?>

       <section class="py-3 m-3">
          <div class="container">
             <div class="row">
                <div style="border-color: lightblue; border-style: solid;" class="col-md-3 m-3 text-center">
                   <h4 class="text-info">Total Queries: </h4>
                   <p class="text-info"><?php echo $word_data['totalQueries'];  ?> Queries</p>
                </div>
                <div style="border-color: green; border-style: solid;" class="col-md-3 m-3 text-center">
                   <h4 class="text-success">Unique Percent: </h4>
                   <p class="text-success"><?php echo $word_data['uniquePercent']; ?>%</p>
                </div>
                <div style="border-color: red; border-style: solid;" class="col-md-3 m-3 text-center">
                   <h4 class="text-danger">Plagiarized Percent: </h4>
                   <p class="text-danger"><?php echo $word_data['plagPercent']; ?></p>
                </div>
             </div>
             <div class="row">
                <h6 class="text-center font-italic">Plagiarized text and reference</h6>
             </div>
          </div>
       </section>




       <?php
         foreach ($order_details as $o) {

            $matched_urls = (array) $o->display;
            if ($matched_urls == null) {
            } else {
               // echo $o->query;
               // echo '<br>';

               $in_query = "<br> " . $o->query . "<br> ";
               $in_urls = "<br> " . $matched_urls['url'] . "<br> ";

               // echo $matched_urls['url'];
               // echo '<br><br>';


         ?>

             <section id="contact" class="py-3 mt-1">
                <div class="container">
                   <div class="row">
                      <div class="col-md-12">
                         <div style="border-color: red; border-style: double;" class="card p-4">
                            <p class="text-danger font-weight-bold">
                               <?php echo $o->query; ?> </p>
                            <a href="<?php echo $matched_urls['url']; ?>">
                               <?php echo $matched_urls['url']; ?>
                            </a>
                         </div>
                      </div>
                   </div>
                </div>
             </section>



 <?php


            }

         }

                              $query = "INSERT INTO results(std_id, doc_id, total_queries, unique_percent, plagiarized_percent, query, urls) ";
                              $query .= "VALUES('{$_SESSION['std_id']}','{$_SESSION['doc_id']}', '{$word_data['totalQueries']}',
                              '{$word_data['uniquePercent']}','{$word_data['plagPercent']}','{$in_query}','{$in_urls}') ";

                              $results_query = mysqli_query($connection, $query);

                              if (!$results_query) {
                                 die("Query failed" . mysqli_error($connection));
                              }

      } catch (Exception $e) {
         error_log("Failed to get data details: " . $e->getMessage(), 0);
      }
   }

   ?>





 <?php include("../includes/footer.php"); ?>