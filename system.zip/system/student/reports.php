 <?php
   include("../includes/header.php");
   include("../student/navbar.php");
   include("../includes/functions.php");
   ?>

 <section class="py-3 mb-3 bg-light">
    <div class="info-header">
       <h5 class="text-info text-center">
          Your reports
       </h5>
    </div>
 </section>

 <!-- Posts -->
 <section id="posts">
    <div class="container">
       <div class="row">
          <div class="col-md-12">
             <div class="card">
                <div class="card-header">
                   <h4>Students</h4>
                </div>
                <table class="table table-striped table-bordered">
                   <thead class="thead-dark">
                      <tr>
                         <th>#</th>
                         <th>Firstname</th>
                         <th>Lastname</th>
                         <!-- <th>Email</th> -->
                         <th>Puporse of upload</th>
                         <th>Text</th>
                         <!-- <th>Doc#</th>
                         <th>Results #</th> -->
                         <th>Total queries</th>
                         <th>Unique percent</th>
                         <th>Plagiarism percent</th>
                         <th>Date</th>

                      </tr>
                   </thead>
                   <tbody>

                      <?php

                        $query = "SELECT * FROM students JOIN documents ON students.std_id = documents.std_id 
                        JOIN results ON documents.doc_id = results.doc_id WHERE students.std_id = '{$_SESSION['std_id']}' ";

                        $select_all_students = mysqli_query($connection, $query);

                        while ($row = mysqli_fetch_assoc($select_all_students)) {

                           $std_id = $row['std_id'];
                           $firstname = $row['firstname'];
                           $lastname = $row['lastname'];
                           // $email = $row['email'];
                           $purpose_of_upload = $row['purpose_of_upload'];
                           $upload_document = $row['upload_document'];
                           $doc_id = $row['doc_id'];
                           $result_id = $row['result_id'];
                           $total_queries = $row['total_queries'];
                           $unique_percent = $row['unique_percent'];
                           $plagiarized_percent = $row['plagiarized_percent'];
                           $date_uploaded = $row['date_uploaded'];

                        ?>
                         <tr>
                            <td><?php echo $std_id; ?></td>
                            <td><?php echo $firstname; ?></td>
                            <td><?php echo $lastname; ?></td>

                            <td><?php echo $purpose_of_upload; ?></td>
                            <td>
                               <?php
                                 echo implode(' ', array_slice(explode(' ', $upload_document), 0, 5)) . "....";
                                 ?>
                            </td>
                            <td class="text-info font-weight-bold"><?php echo $total_queries; ?>%</td>
                            <td class="text-success font-weight-bold"><?php echo $unique_percent; ?>%</td>
                            <td class="text-danger font-weight-bold"><?php echo $plagiarized_percent; ?>%</td>
                            <td><?php echo $date_uploaded; ?></td>
                         </tr>


                      <?php }; ?>






                   </tbody>
                </table>
             </div>
          </div>
       </div>
    </div>
 </section>















 <?php include("../includes/footer.php"); ?>