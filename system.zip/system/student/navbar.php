<?php
include_once('../includes/db.php');

$query = "SELECT * FROM students WHERE std_id = '{$_SESSION['std_id']}'";
$select_all_students = mysqli_query($connection, $query);

while ($row = mysqli_fetch_assoc($select_all_students)) {

   $std_id = $row['std_id'];
   $firstname = $row['firstname'];
   $lastname = $row['lastname'];
   $email = $row['email'];
   $status = $row['status'];
}


?>


<nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
   <div class="container">
      <a href="index.php" class="navbar-brand">Student</a>
      <buttton class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
         <span class="navbar-toggler-icon"></span>
      </buttton>
      <div class="collapse navbar-collapse" id="navbarCollapse">
         <ul class="navbar-nav">
            <li class="nav-item px-2">
               <a href="index.php" class="nav-link">Home</a>
            </li>

            <li class="nav-item px-2">
               <a href="reports.php" class="nav-link">Reports</a>
            </li>
         </ul>

         <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown mr-3">
               <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                  <i class="fas fa-user"></i>
                  <?php
                  echo $firstname;
                  ?>
               </a>
               <div class="dropdown-menu">
                  <a href="profile.html" class="dropdown-item">
                     <i class="fas fa-user-circle"></i>Profile
                  </a>
                  <a href="setting.html" class="dropdown-item">
                     <i class="fas fa-cog"></i>Settings
                  </a>
               </div>
            </li>
            <li class="nav-item">
               <a href="../index.php" class="nav-link">
                  <i class="fas fa-user-times"></i> Logout
               </a>
            </li>
         </ul>
      </div>
   </div>
</nav>